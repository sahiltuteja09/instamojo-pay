<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Instamojo_model extends CI_Model {
    /*
     *  Login to Sandbox (TEST) account on instamojo to get test API key and token
     *   https://test.instamojo.com/integrations/
     * 
     *  For Production API key & Token
     *  https://www.instamojo.com/integrations
     * 
     */

// request variable
    private $api_key = 'ae7ddc7a4d578f0f47e3c3cef3fb59d7'; //'b4bc4e2a20afc093eae01e79db31af9c'; //( required )
    private $auth_token = '590f21582497906a227b1dcba8f75c83'; //'bcc29cd8da11bef2799ad5fd567f8e9c'; //( required )
    private $salt = '225978a03e414ec19ccc7dd9389eabe0'; //'66417f78ac234d4586456f99d21f7224'; // get salt from instamojo account ( required )
    private $endpoint = 'https://test.instamojo.com/api/1.1/'; // ( required ) production endpoint ( https://www.instamojo.com/api/1.1/ )
    public $currency = 'INR';
    public $allow_repeated_payments = true; // if set false the payment link can be use once after the payment it expire
    public $send_email = true; // if you want to send payment confirmation email
    public $send_sms = true; // if you want to send payment confirmation sms to user
    public $purpose = "Test"; // title of the products
    public $amount = 10; // required [ Minmium amount is 9 ]
//    var $partner_fee_type = 'fixed'; // can be in "percent"  // Allows you to receive a cut from
//    var $partner_fee = "00.00";
//    var $status = "pending"; // default pending // can be changed in response ( Pending, Sent, Failed, Completed )
//    var $sms_status = "pending"; // default pending // can be changed in response ( Pending, Sent, Failed, Completed )
//    var $email_status = "pending"; // default pending // can be changed in response ( Pending, Sent, Failed, Completed )
    // response variable
    protected $mac = ''; // for securty check of the paytment .
    protected $mac_calculated = ''; // calculate the mac from the response

    function __construct() {
        parent::__construct();
    }

    function error_control($type = '') {
        // if not user then print json error to loged in
        $json['error'] = '';

        switch ($type) {

            case 55 :
                $error = "MAC not found.";
                return $error;
                exit;
                break;
            case 56 :
                $error = "MAC mismatch.";
                return $error;
                exit;
                break;
            case 57 :
                $error = "Payment failed or cancel by user";
                return $error;
                exit;
                break;

            default:
                break;
        }
    }

    function pay($data = array()) {
        if (!$this->api_key)
            die("The API Key is required");
        if (!$this->auth_token)
            die("The API Auth Token is required");
        $param = array(
            'api_key' => $this->api_key,
            'auth_token' => $this->auth_token,
            'endpoint' => $this->endpoint
        );


        if (empty($data) && !is_array($data)) {
            return false;
        }
        $this->load->library('instamojo', $param);

        // user detail
        $request['buyer_name'] = $data['buyer_name'];
        $request['email'] = $data['email'];
        $request['phone'] = $data['phone'];

        // product detail
        $request['amount'] = $data['amount'] < 9 ? $this->amount : $data['amount'];
        $request['purpose'] = $data['title'] == '' ? $this->purpose : $data['title'];

        // instamojo action
        $request['send_email'] = $this->send_email; // default true
        $request['send_sms'] = $this->send_sms; // default true
        $request['currency'] = $this->currency; // default INR
        $request['allow_repeated_payments'] = $this->allow_repeated_payments; // default true



        if (!isset($data['redirect_url']) || $data['redirect_url'] == '') {

            die('Redirect URL Required.');
        } else {
            $request['redirect_url'] = $data['redirect_url']; //URL where user redirect after payment done
        }

        if (!isset($data['response_url']) || $data['response_url'] == '') {

            die('Response URL is required.');
        } else {
            $request['webhook'] = $data['response_url']; // POST requests made by Instamojo server after successful payment.
        }

        $response = $this->instamojo->paymentRequestCreate($request);
        if (!$response['success']) {
            foreach ($response['message'] as $key => $value) {
                echo $key . ' : ' . implode("<br/>", $value) . '<br/>';
            }
            return false;
        } else {
            return $response['payment_request'];
        }
    }

    function set_mac() {
        $data = $this->input->post();
        $this->mac = $data['mac'];  // Get the MAC from the POST data
        unset($data['mac']);  // Remove the MAC key from the data.
        $ver = explode('.', phpversion());
        $major = (int) $ver[0];
        $minor = (int) $ver[1];
        if ($major >= 5 and $minor >= 4) {
            ksort($data, SORT_STRING | SORT_FLAG_CASE);
        } else {
            uksort($data, 'strcasecmp');
        }
// You can get the 'salt' from Instamojo's developers page(make sure to log in first): https://www.instamojo.com/developers
        $s = $this->salt;
        $this->mac_calculated = hash_hmac("sha1", implode("|", $data), "$s");

        return $data;
    }

    function verify_request() {
        $response = self::set_mac();
        $mac_provided = $this->mac;
        $calculated_mac = $this->mac_calculated;


        $return = array();

        if (!$mac_provided || !$calculated_mac) {
            $return['status'] = 'failed';
            $return['error'] = self::error_control(55); // MAC not found 
            return $return;
            exit();
        }


        if ($mac_provided == $calculated_mac) {
            if ($response['status'] == "Credit") {
                // Payment was successful, mark it as successful in your database.
                // You can acess payment_request_id, purpose etc here. 
                $return['status'] = 'paid';
                $return['response'] = $response;
                return $return;
                exit();
            } else {
                // Payment was unsuccessful, mark it as failed in your database.
                // You can acess payment_request_id, purpose etc here.
                $return['status'] = 'failed';
                $return['error'] = self::error_control(57); // Payment failed
                return $return;
                exit();
            }
        } else {
            $return['status'] = 'failed';
            $return['error'] = self::error_control(56); // MAC mismatch 
            return $return;
            exit();
        }
    }

    function update_order($table = '', $condition = array(), $set = array()) {
        if (!$table)
            die('table name required');
        if (empty($condition) || !is_array($condition))
            die('Condition must be an array.');
        if (empty($set) || !is_array($set))
            die('Update value must be an array.');

        $this->db->set($set);
        $this->db->where($condition);
        $this->db->update($table);
    }

    function save_response($table, $save) {
        if (!$table)
            die('table name required');
        if (empty($save) || !is_array($save))
            die('Insert value must be array.');

        $this->db->set($save);
        $this->db->insert($table);

        if ($this->db->affected_rows() == 1) {
            return true;
        } else {
            return false;
        }
    }
}
