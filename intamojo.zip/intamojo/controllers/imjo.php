<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Imjo extends CI_Controller {

    var $session_user = '';

    function __construct() {
        parent::__construct();
        $this->load->model('instamojo_model', 'imjo');
        $this->load->model('user_model', 'user');

        $this->session_user = $this->auth->user();
    }

    function get_user() {
        $error = '';

        // getting user id from session
        $id = $this->session_user['id'];
        if (!$id)
            $error = 'Logged in Required.';
        $user = $this->user->account($id);
        if (empty($user))
            $error = "Logged in Required.";
        if ($error) {
            $json['error'] = $error;
            echo json_encode($json);
            die;
        }


        $data['buyer_name'] = $user->username;
        $data['email'] = $user->email;
        $data['phone'] = $user->phone;

        return $data;
    }

    function get_product() {
        $data['title'] = "Test query";
        $data['amount'] = 11;
        return $data;
    }

    function pay() {
        $user = self::get_user();
        $product = self::get_product();
        $data = array_merge($user, $product);

        $redirect['redirect_url'] = base_url() . "imjo/redirect_url";
        $redirect['response_url'] = base_url() . "imjo/response_data";
        $data = array_merge($data, $redirect);
        $response = $this->imjo->pay($data);
//        pr($response);
//        die;
        if (!empty($response)) {
            $save = self::save_response($response);
            // now redirect user to directly on payment page
            if ($save) {
                // To use light checkout, simply append ?embed=form at the end of your request URL.
                $pay_url = $response['longurl'] . '?embed=form'; // ?embed=form is optional 
                redirect($pay_url);
            } else {
                die('Instamojo response error.');
            }
        } else {
            die('Payment gateway error!! Please contact to admin.');
        }
    }

    // set redirect URL here
    function redirect_url() {
        redirect(base_url());
    }

    // after successful payment response data posted by instamojo here
    function response_data() {
        //   $this->load->library('myemail');

        $response = $this->imjo->verify_request();
        // $data = json_encode($response);
        // $this->myemail->sendby_smtp('contact@freeclues.com','test response', "$data");
        if ($response['status'] == 'paid') {
            // mark payment to paid in respect to instamojo_payment_request_id
            self::update_order($response['response'], 'paid');
        } else {
            // mark payment to failed in respect to instamojo payment id
            self::update_order($response['response'], 'failed');
        }
    }

    function update_order($paymentDetail = array(), $status) {

        $update['instamojo_payment_id'] = $paymentDetail['payment_id'];
        $update['status'] = $status;
        $update['modified_at'] = date('Y-m-d H:i:s');
        $where['instamojo_payment_request_id'] = $paymentDetail['payment_request_id'];

        $table = 'order';
        $conditions = $where;
        $set = $update;
        $this->imjo->update_order($table, $conditions, $set);
    }

    // before payment instamojo provide us data to save in our end
    // here we save the data to identify the payment
    function save_response($response = array()) {
        if (empty($response))
            return false;

        // save response to db for payment status update when user pay 
        $save['instamojo_payment_id'] = 0;
        $save['instamojo_payment_request_id'] = $response['id'];

        // user details
        $save['user_id'] = $this->session_user['id'];
        $save['email'] = $response['email'];
        $save['username'] = $response['buyer_name'];
        $save['phone'] = str_replace("+91", '', $response['phone']);

        // product detail
        $save['title'] = $response['purpose'];
        $save['amount'] = $response['amount'];

        // order detail
        $save['order_number'] = time() . $save['user_id'];
        $save['status'] = strtolower($response['status']);
        $save['created_at'] = date('Y-m-d H:i:s');
        $save['modified_at'] = date('Y-m-d H:i:s');

        $table = 'order';
        // $this->load->model('instamojo_model', 'imjo');


        $insert_record = $this->imjo->save_response($table, $save);

        return $insert_record; //is response succesuffly save then return true for acknowledgement
    }

}
